package snu.kdd.synonym.container;

public class ObjectArrayList {

}
