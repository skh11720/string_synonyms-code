package validator;

public class DefaultValidator extends TopDownHashSetSinglePath_DS {
	public DefaultValidator() {
		super();
	}
}
