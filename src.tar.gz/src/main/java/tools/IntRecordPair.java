package tools;

import mine.Record;

public class IntRecordPair {
	public int min;
	public int max;
	public Record rec;

	public IntRecordPair( int min, int max, Record rec ) {
		this.min = min;
		this.max = max;
		this.rec = rec;
	}
}
